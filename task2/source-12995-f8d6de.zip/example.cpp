#include "example.h"

#include <iostream>

void example_function() {
	std::cout << "Hello from example function!" << std::endl;
}